package com.goldvision.ai

import android.content.Context
import android.graphics.*
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class Level(val ar: String, val color: Int) {
    HIGH("اشتباه بصري مرتفع", 0xFF2E7D32.toInt()),
    MEDIUM("اشتباه بصري متوسط", 0xFFEF6C00.toInt()),
    LOW("اشتباه بصري ضعيف", 0xFF757575.toInt())
}

fun levelOf(score: Int) = if (score >= 70) Level.HIGH else if (score >= 45) Level.MEDIUM else Level.LOW

/** box: إحداثيات مُطبَّعة 0..1 بالنسبة للصورة */
data class Finding(
    val box: RectF,
    val score: Int,
    val stamp: String?,
    val plated: Boolean,
    val reasons: List<String>
) {
    val level get() = levelOf(score)
}

const val DISCLAIMER =
    "هذه النتيجة تقدير بصري فقط وليست إثباتاً لتركيب المعدن. الذهب المطلي والنحاس الأصفر والإكسسوارات " +
        "قد تبدو متشابهة بالكاميرا، والدمغة نفسها قد تكون مقلّدة. للتأكد استخدم حجر المحك/الحمض أو جهاز XRF أو مختبراً معتمداً."

object GoldAnalyzer {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private const val WORK = 480 // أكبر بُعد للتحليل اللوني (السرعة)

    private class Comp(val id: Int, val x0: Int, val y0: Int, val x1: Int, val y1: Int, val cnt: Int)

    /** المرحلة 1 (سريعة، بدون OCR): تحديد المناطق ذات لون الذهب وتحليل لونها ولمعانها وملمسها. */
    fun detect(src: Bitmap): List<Finding> {
        val sc = WORK.toFloat() / max(src.width, src.height)
        val w = max(1, (src.width * sc).toInt())
        val h = max(1, (src.height * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        val hs = FloatArray(w * h); val ss = FloatArray(w * h); val vs = FloatArray(w * h)
        val mask = BooleanArray(w * h)
        val hsv = FloatArray(3)
        for (i in px.indices) {
            Color.colorToHSV(px[i], hsv)
            hs[i] = hsv[0]; ss[i] = hsv[1]; vs[i] = hsv[2]
            mask[i] = hsv[0] in 28f..58f && hsv[1] in 0.25f..0.95f && hsv[2] >= 0.30f
        }
        // إغلاق مورفولوجي بسيط حتى لا تقسم اللمعات البيضاء القطعة إلى أجزاء
        val dm = dilate(dilate(mask, w, h), w, h)

        val label = IntArray(w * h)
        val stack = IntArray(w * h)
        val comps = ArrayList<Comp>()
        var next = 0
        for (i in dm.indices) {
            if (!dm[i] || label[i] != 0) continue
            next++
            var sp = 0; stack[sp++] = i; label[i] = next
            var x0 = w; var x1 = 0; var y0 = h; var y1 = 0; var cnt = 0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                cnt++
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                if (x > 0 && dm[p - 1] && label[p - 1] == 0) { label[p - 1] = next; stack[sp++] = p - 1 }
                if (x < w - 1 && dm[p + 1] && label[p + 1] == 0) { label[p + 1] = next; stack[sp++] = p + 1 }
                if (y > 0 && dm[p - w] && label[p - w] == 0) { label[p - w] = next; stack[sp++] = p - w }
                if (y < h - 1 && dm[p + w] && label[p + w] == 0) { label[p + w] = next; stack[sp++] = p + w }
            }
            val bboxArea = (x1 - x0 + 1) * (y1 - y0 + 1)
            if (cnt >= 0.0015f * w * h && bboxArea <= 0.6f * w * h) comps.add(Comp(next, x0, y0, x1, y1, cnt))
        }

        val out = ArrayList<Finding>()
        for (c in comps.sortedByDescending { it.cnt }.take(12)) {
            var n = 0; var tot = 0; var spec = 0
            var sH = 0.0; var sS = 0.0; var sV = 0.0; var sV2 = 0.0
            for (y in c.y0..c.y1) for (x in c.x0..c.x1) {
                val p = y * w + x
                if (label[p] != c.id) continue
                tot++
                if (mask[p]) {
                    n++; sH += hs[p]; sS += ss[p]; sV += vs[p]; sV2 += vs[p] * vs[p]
                } else if (vs[p] > 0.88f && ss[p] < 0.30f) spec++
            }
            if (n < 20) continue
            val mH = sH / n; val mS = sS / n; val mV = sV / n
            val sdV = sqrt(max(0.0, sV2 / n - mV * mV))
            val specRatio = spec.toDouble() / tot

            val reasons = ArrayList<String>()
            var score = 0.0

            val hScore = max(0.0, 30 - abs(mH - 44) * 2.5)
            score += hScore
            reasons += when {
                hScore >= 20 -> "درجة اللون قريبة من الأصفر الذهبي"
                mH > 52 -> "اللون يميل إلى الأصفر المخضر (يشبه النحاس الأصفر أكثر)"
                mH < 36 -> "اللون يميل إلى المحمر (قد يكون نحاساً أو ذهباً وردياً)"
                else -> "اللون ذهبي جزئياً فقط"
            }

            val sScore = max(0.0, 25 - abs(mS - 0.55) * 100)
            score += sScore
            if (mS > 0.80) reasons += "تشبّع اللون عالٍ جداً (يرتبط بالطلاء أو الأصباغ الصفراء)"
            else if (mS < 0.32) reasons += "اللون باهت (قد يكون ذهباً أبيض/فضة مذهّبة أو إضاءة ضعيفة)"
            else reasons += "تشبّع اللون ضمن المعتاد للمعدن الأصفر"

            val specScore = when {
                specRatio in 0.015..0.15 -> 20.0
                specRatio < 0.003 -> 0.0
                else -> 8.0
            }
            score += specScore
            reasons += if (specScore >= 20) "توجد لمعات انعكاسية معدنية" else if (specScore == 0.0) "لا توجد لمعات انعكاسية (قد يكون سطحاً مطفياً/بلاستيكاً/ضوءاً ضعيفاً)" else "لمعان انعكاسي جزئي"

            val tScore = when {
                sdV in 0.10..0.28 -> 15.0
                sdV < 0.05 -> 0.0
                else -> 7.0
            }
            score += tScore
            if (tScore == 0.0) reasons += "السطح متجانس جداً بلا تدرّج ضوئي معدني"

            val pad = 0.03f
            val box = RectF(
                max(0f, c.x0.toFloat() / w - pad), max(0f, c.y0.toFloat() / h - pad),
                min(1f, (c.x1 + 1).toFloat() / w + pad), min(1f, (c.y1 + 1).toFloat() / h + pad)
            )
            out += Finding(box, score.toInt().coerceIn(0, 90), null, false, reasons)
        }
        return out.sortedByDescending { it.score }
    }

    /** المرحلة 2 (أبطأ): التحليل اللوني + قراءة الدمغة من الصورة الأصلية عالية الدقة. */
    suspend fun analyze(src: Bitmap): List<Finding> = withContext(Dispatchers.Default) {
        detect(src).map { f -> applyStamp(f, readText(crop(src, f.box))) }
    }

    private class StampInfo(val stamp: String?, val plated: Boolean)

    private val platedRx = Regex("GEP|HGE|RGP|PLATED|ELECTROPLATE|K\\s?GP|K\\s?GF|(?<![A-Z])GP(?![A-Z])|(?<![A-Z])GF(?![A-Z])", RegexOption.IGNORE_CASE)
    private val karatRx = Regex("(?<![0-9])(9|10|14|18|21|22|24)\\s?K(?![A-Z])", RegexOption.IGNORE_CASE)
    private val finenessRx = Regex("(?<![0-9])(375|585|750|875|916|999)(?![0-9])")
    private val fineToK = mapOf("375" to "9K", "585" to "14K", "750" to "18K", "875" to "21K", "916" to "22K", "999" to "24K")

    private fun parse(t: String): StampInfo? {
        val plated = platedRx.containsMatchIn(t)
        val k = karatRx.find(t)?.groupValues?.get(1)?.let { "${it}K" }
        val f = finenessRx.find(t)?.groupValues?.get(1)?.let { "$it (≈${fineToK[it]})" }
        val stamp = k ?: f
        return if (plated || stamp != null) StampInfo(stamp, plated) else null
    }

    private suspend fun readText(b: Bitmap): String {
        val up = if (max(b.width, b.height) < 900) {
            val s = 900f / max(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
        } else b
        val sb = StringBuilder()
        for (rot in intArrayOf(0, 90, 270)) {
            val bm = rotate(up, rot)
            sb.append(' ').append(recognizer.process(InputImage.fromBitmap(bm, 0)).await().text)
            if (parse(sb.toString()) != null) break
        }
        return sb.toString()
    }

    private fun applyStamp(f: Finding, text: String): Finding {
        val info = parse(text)
        val reasons = f.reasons.toMutableList()
        var score = f.score
        var stamp: String? = null
        var plated = false
        if (info == null) {
            reasons += "لم تُقرأ دمغة (قد تكون صغيرة جداً أو غير واضحة؛ جرّب تقريباً قريباً وإضاءة جانبية)"
        } else {
            stamp = info.stamp; plated = info.plated
            if (plated) {
                score = min(score, 35)
                reasons += "قُرئ رمز طلاء (GP/GEP/HGE...) ← الأرجح قطعة مطلية"
            } else {
                score = min(100, score + 10)
                reasons += "قُرئت دمغة ${info.stamp} (قراءة OCR قد تخطئ ودمغة الذهب قد تكون مقلّدة)"
            }
        }
        return f.copy(score = score, stamp = stamp, plated = plated, reasons = reasons)
    }

    private fun dilate(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) if (m[y * w + x]) {
            for (dy in -1..1) for (dx in -1..1) {
                val nx = x + dx; val ny = y + dy
                if (nx in 0 until w && ny in 0 until h) o[ny * w + nx] = true
            }
        }
        return o
    }

    fun crop(src: Bitmap, b: RectF): Bitmap {
        val x = (b.left * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (b.top * src.height).toInt().coerceIn(0, src.height - 1)
        val w = ((b.right - b.left) * src.width).toInt().coerceIn(1, src.width - x)
        val h = ((b.bottom - b.top) * src.height).toInt().coerceIn(1, src.height - y)
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    fun annotate(src: Bitmap, fs: List<Finding>): Bitmap {
        val bm = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(bm)
        val unit = max(bm.width, bm.height) / 400f
        val stroke = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * unit; isAntiAlias = true }
        val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
        val txt = Paint().apply { color = Color.WHITE; textSize = 12f * unit; isAntiAlias = true; isFakeBoldText = true }
        fs.forEachIndexed { i, f ->
            stroke.color = f.level.color; fill.color = f.level.color
            val r = RectF(f.box.left * bm.width, f.box.top * bm.height, f.box.right * bm.width, f.box.bottom * bm.height)
            c.drawRoundRect(r, 6 * unit, 6 * unit, stroke)
            val label = "${i + 1}  ${f.score}"
            val tw = txt.measureText(label) + 8 * unit
            c.drawRect(r.left, r.top - 16 * unit, r.left + tw, r.top, fill)
            c.drawText(label, r.left + 4 * unit, r.top - 4 * unit, txt)
        }
        return bm
    }
}

fun rotate(b: Bitmap, deg: Int): Bitmap =
    if (deg % 360 == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

fun limit(b: Bitmap, maxSide: Int): Bitmap {
    val m = max(b.width, b.height)
    if (m <= maxSide) return b
    val s = maxSide.toFloat() / m
    return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
}

fun decodeUri(ctx: Context, uri: Uri): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (max(o.outWidth, o.outHeight) / s > 3000) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
} catch (e: Exception) { null }
