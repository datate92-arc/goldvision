package com.goldvision.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF8A6D00))) {
                CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

sealed class Screen {
    object Home : Screen()
    data class Cam(val live: Boolean) : Screen()
    data class Res(val bmp: Bitmap, val findings: List<Finding>, val saved: Boolean) : Screen()
    object Hist : Screen()
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var busy by remember { mutableStateOf(false) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var pendingLive by remember { mutableStateOf<Boolean?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok) pendingLive?.let { screen = Screen.Cam(it) }
        pendingLive = null
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val bmp = withContext(Dispatchers.IO) { decodeUri(ctx, uri) }
            if (bmp != null) screen = Screen.Res(bmp, GoldAnalyzer.analyze(bmp), false)
            busy = false
        }
    }
    fun openCam(live: Boolean) {
        if (granted) screen = Screen.Cam(live) else { pendingLive = live; permLauncher.launch(Manifest.permission.CAMERA) }
    }

    BackHandler(screen !is Screen.Home) { screen = Screen.Home }

    Surface(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            when (val s = screen) {
                Screen.Home -> HomeScreen(
                    onStart = { openCam(false) }, onLive = { openCam(true) },
                    onGallery = { picker.launch("image/*") }, onHistory = { screen = Screen.Hist }
                )
                is Screen.Cam -> CameraScreen(s.live, { b, f -> screen = Screen.Res(b, f, false) }, { screen = Screen.Home })
                is Screen.Res -> ResultScreen(s.bmp, s.findings, s.saved) { screen = Screen.Home }
                Screen.Hist -> HistoryScreen(
                    onOpen = { sc ->
                        val b = HistoryStore.loadBitmap(ctx, sc.id, 2000)
                        if (b != null) screen = Screen.Res(b, sc.findings, true)
                    },
                    onBack = { screen = Screen.Home }
                )
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color(0x99000000)), Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@Composable
fun HomeScreen(onStart: () -> Unit, onLive: () -> Unit, onGallery: () -> Unit, onHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Gold Vision AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8A6D00))
        Text("مساعد فحص بصري للقطع الذهبية المحتملة", fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Button(onStart, Modifier.fillMaxWidth().height(56.dp)) { Text("بدء الفحص / التقاط صورة", fontSize = 17.sp) }
        Button(onLive, Modifier.fillMaxWidth().height(56.dp)) { Text("فحص مباشر بالكاميرا", fontSize = 17.sp) }
        OutlinedButton(onGallery, Modifier.fillMaxWidth().height(52.dp)) { Text("فحص صورة من المعرض") }
        OutlinedButton(onHistory, Modifier.fillMaxWidth().height(52.dp)) { Text("سجل الفحوصات") }
        Spacer(Modifier.weight(1f))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) {
            Text(DISCLAIMER, Modifier.padding(14.dp), fontSize = 13.sp)
        }
        Text("نصيحة: ضوء نهار منتشر، بدون فلاش، وقطع غير متراكمة، وللدمغات صوّر كل قطعة عن قرب.", fontSize = 12.sp)
    }
}

@Composable
fun CameraScreen(initialLive: Boolean, onResult: (Bitmap, List<Finding>) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val executor = remember { Executors.newSingleThreadExecutor() }
    var live by remember { mutableStateOf(initialLive) }
    val liveNow = rememberUpdatedState(live)
    var liveFindings by remember { mutableStateOf<List<Finding>>(emptyList()) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoom by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val capture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build() }
    val analysis = remember {
        ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
    }

    DisposableEffect(Unit) {
        var last = 0L
        analysis.setAnalyzer(executor) { proxy ->
            try {
                val now = SystemClock.elapsedRealtime()
                if (liveNow.value && now - last > 250) {
                    last = now
                    val bmp = rotate(proxy.toBitmap(), proxy.imageInfo.rotationDegrees)
                    liveFindings = GoldAnalyzer.detect(bmp).filter { it.score >= 45 }
                }
            } catch (e: Exception) { /* تجاهل إطار فاشل */ } finally { proxy.close() }
        }
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            provider.unbindAll()
            camera = provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture, analysis)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            analysis.clearAnalyzer()
            try { future.get().unbindAll() } catch (e: Exception) { }
        }
    }
    LaunchedEffect(live) { if (!live) liveFindings = emptyList() }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("رجوع", color = Color.White) }
            Spacer(Modifier.weight(1f))
            Text("تحليل مباشر", color = Color.White)
            Spacer(Modifier.width(8.dp))
            Switch(live, { live = it })
        }
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())
            Canvas(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTapGestures { o ->
                        camera?.let { c ->
                            val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                            c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                        }
                    }
                }
            ) {
                val p = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 34f; isFakeBoldText = true }
                liveFindings.forEach { f ->
                    val tl = Offset(f.box.left * size.width, f.box.top * size.height)
                    val sz = Size((f.box.right - f.box.left) * size.width, (f.box.bottom - f.box.top) * size.height)
                    drawRect(Color(f.level.color), tl, sz, style = Stroke(5f))
                    drawContext.canvas.nativeCanvas.drawText("${f.score}", tl.x + 6, tl.y + 36, p)
                }
            }
        }
        Slider(zoom, { zoom = it; camera?.cameraControl?.setLinearZoom(it) }, Modifier.padding(horizontal = 24.dp))
        Text("تقريب", color = Color.White, modifier = Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp)
        error?.let { Text(it, color = Color.Red, modifier = Modifier.padding(8.dp)) }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = {
                busy = true; error = null
                capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val bmp = try { limit(rotate(image.toBitmap(), image.imageInfo.rotationDegrees), 2400) } finally { image.close() }
                        scope.launch {
                            val f = GoldAnalyzer.analyze(bmp)
                            busy = false
                            onResult(bmp, f)
                        }
                    }
                    override fun onError(exception: ImageCaptureException) { busy = false; error = "فشل التقاط الصورة" }
                })
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
        ) { Text(if (busy) "جارٍ التحليل..." else "التقاط وفحص دقيق (مع قراءة الدمغات)", fontSize = 16.sp) }
    }
}

@Composable
fun ResultScreen(bmp: Bitmap, findings: List<Finding>, saved: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val annotated = remember(bmp, findings) { GoldAnalyzer.annotate(bmp, findings) }
    LaunchedEffect(Unit) { if (!saved) withContext(Dispatchers.IO) { HistoryStore.save(ctx, bmp, findings) } }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onBack) { Text("الرئيسية") }
                Text("نتائج الفحص (${findings.size} قطعة)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
        item { Image(annotated.asImageBitmap(), null, Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) { Text(DISCLAIMER, Modifier.padding(12.dp), fontSize = 12.sp) } }
        if (findings.isEmpty()) item { Text("لم يتم العثور على قطع بلون الذهب. جرّب إضاءة أفضل أو تقريباً أكبر.") }
        items(findings.size) { i ->
            val f = findings[i]
            val thumb = remember(bmp, f) { GoldAnalyzer.crop(bmp, f.box) }
            Card {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Image(thumb.asImageBitmap(), null, Modifier.size(96.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("قطعة ${i + 1}: ${f.level.ar}", fontWeight = FontWeight.Bold, color = Color(f.level.color))
                        Text("درجة الاشتباه البصري: ${f.score} / 100 (مؤشر داخلي غير معايَر، وليس نسبة دقة)", fontSize = 12.sp)
                        Text("الدمغة: " + (f.stamp ?: if (f.plated) "رمز طلاء" else "لم تُقرأ"), fontSize = 13.sp)
                        f.reasons.forEach { Text("• $it", fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(onOpen: (Scan) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var scans by remember { mutableStateOf(HistoryStore.list(ctx)) }
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("الرئيسية") }
            Text("سجل الفحوصات", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        if (scans.isEmpty()) Text("لا توجد فحوصات محفوظة بعد.", Modifier.padding(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(scans, key = { it.id }) { sc ->
                val thumb = remember(sc.id) { HistoryStore.loadBitmap(ctx, sc.id, 300) }
                Card(Modifier.fillMaxWidth().clickable { onOpen(sc) }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        thumb?.let { Image(it.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop) }
                        Column(Modifier.weight(1f)) {
                            Text(fmt.format(Date(sc.time)))
                            Text("${sc.findings.size} قطعة، أعلى درجة: ${sc.findings.maxOfOrNull { it.score } ?: 0}", fontSize = 12.sp)
                        }
                        TextButton({ HistoryStore.delete(ctx, sc.id); scans = HistoryStore.list(ctx) }) { Text("حذف", color = Color.Red) }
                    }
                }
            }
        }
    }
}
