"""
تدريب مصنِّف قصاصات القطع (Transfer Learning) وتصديره إلى TensorFlow Lite لتطبيق Gold Vision AI.

لم يُشغَّل هذا السكربت على بياناتك؛ هو قالب جاهز. دقة النموذج تعتمد كلياً على بياناتك.

بنية مجلد البيانات (قصاصات لقطع فردية، بإضاءات وزوايا وخلفيات متنوعة، وتصنيفها موثَّق بحجر المحك/XRF/مختبر):
  data/
    gold_candidate/            # ذهب حقيقي مؤكَّد
    plated_or_other_metal/     # مطلي، نحاس أصفر، إكسسوار عادي مؤكَّد
    background/                # خلفيات وأشياء ليست قطعاً
التشغيل:
  pip install tensorflow
  python tools/train_classifier.py --data data --out app/src/main/assets
يُنتج gold_classifier.tflite و labels.txt ويطبع تقرير مصفوفة الالتباس على بيانات تحقق منفصلة.
ملاحظة: لا تنشر أي رقم دقة إلا من هذا التقرير، ومن قطع لم يرها النموذج في التدريب (يفضَّل من مصدر/محل مختلف).
"""
import argparse, os
import tensorflow as tf

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--out", default="app/src/main/assets")
ap.add_argument("--size", type=int, default=224)
ap.add_argument("--epochs", type=int, default=15)
a = ap.parse_args()

common = dict(image_size=(a.size, a.size), batch_size=32, seed=7, validation_split=0.2, label_mode="int")
train = tf.keras.utils.image_dataset_from_directory(a.data, subset="training", **common)
val = tf.keras.utils.image_dataset_from_directory(a.data, subset="validation", **common)
names = train.class_names
assert "gold_candidate" in names, "يجب وجود مجلد باسم gold_candidate"
print("الأصناف:", names)

aug = tf.keras.Sequential([
    tf.keras.layers.RandomFlip("horizontal_and_vertical"),
    tf.keras.layers.RandomRotation(0.25),
    tf.keras.layers.RandomBrightness(0.25, value_range=(0, 255)),
    tf.keras.layers.RandomContrast(0.25),
])
base = tf.keras.applications.MobileNetV3Small(input_shape=(a.size, a.size, 3), include_top=False, weights="imagenet", include_preprocessing=True)
base.trainable = False
inp = tf.keras.Input((a.size, a.size, 3), dtype="float32")   # قيم 0..255 (نفس عقد التطبيق)
x = aug(inp)
x = base(x, training=False)
x = tf.keras.layers.GlobalAveragePooling2D()(x)
x = tf.keras.layers.Dropout(0.3)(x)
out = tf.keras.layers.Dense(len(names), activation="softmax")(x)
model = tf.keras.Model(inp, out)
model.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
model.fit(train, validation_data=val, epochs=a.epochs)

y_true, y_pred = [], []
for xb, yb in val:
    y_true += yb.numpy().tolist()
    y_pred += tf.argmax(model.predict(xb, verbose=0), axis=1).numpy().tolist()
cm = tf.math.confusion_matrix(y_true, y_pred, num_classes=len(names)).numpy()
print("مصفوفة الالتباس (صفوف=الحقيقة، أعمدة=التوقع):", names)
print(cm)

os.makedirs(a.out, exist_ok=True)
conv = tf.lite.TFLiteConverter.from_keras_model(model)
conv.optimizations = [tf.lite.Optimize.DEFAULT]
open(os.path.join(a.out, "gold_classifier.tflite"), "wb").write(conv.convert())
open(os.path.join(a.out, "labels.txt"), "w", encoding="utf-8").write("\n".join(names) + "\n")
print("تم الحفظ في", a.out)
