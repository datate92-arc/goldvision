package com.goldvision.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Scan(val id: String, val time: Long, val findings: List<Finding>)

/** كل الفحوصات تُخزَّن محلياً داخل التطبيق فقط (filesDir/history). */
object HistoryStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "history").apply { mkdirs() }

    fun save(ctx: Context, bmp: Bitmap, fs: List<Finding>): String {
        val id = System.currentTimeMillis().toString()
        val dir = File(root(ctx), id).apply { mkdirs() }
        File(dir, "photo.jpg").outputStream().use { limit(bmp, 2000).compress(Bitmap.CompressFormat.JPEG, 90, it) }
        val arr = JSONArray()
        fs.forEach { f ->
            arr.put(JSONObject().apply {
                put("l", f.box.left.toDouble()); put("t", f.box.top.toDouble())
                put("r", f.box.right.toDouble()); put("b", f.box.bottom.toDouble())
                put("score", f.score); put("stamp", f.stamp ?: ""); put("plated", f.plated)
                put("reasons", JSONArray(f.reasons))
            })
        }
        File(dir, "meta.json").writeText(JSONObject().put("findings", arr).toString())
        return id
    }

    fun list(ctx: Context): List<Scan> =
        (root(ctx).listFiles() ?: emptyArray()).filter { it.isDirectory }.mapNotNull { d ->
            try {
                val arr = JSONObject(File(d, "meta.json").readText()).getJSONArray("findings")
                val fs = (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    val rs = o.getJSONArray("reasons")
                    Finding(
                        RectF(o.getDouble("l").toFloat(), o.getDouble("t").toFloat(), o.getDouble("r").toFloat(), o.getDouble("b").toFloat()),
                        o.getInt("score"), o.getString("stamp").ifEmpty { null }, o.getBoolean("plated"),
                        (0 until rs.length()).map { rs.getString(it) }
                    )
                }
                Scan(d.name, d.name.toLong(), fs)
            } catch (e: Exception) { null }
        }.sortedByDescending { it.time }

    fun loadBitmap(ctx: Context, id: String, maxSide: Int): Bitmap? {
        val f = File(root(ctx), "$id/photo.jpg")
        if (!f.exists()) return null
        return BitmapFactory.decodeFile(f.path)?.let { limit(it, maxSide) }
    }

    fun delete(ctx: Context, id: String) { File(root(ctx), id).deleteRecursively() }
}
