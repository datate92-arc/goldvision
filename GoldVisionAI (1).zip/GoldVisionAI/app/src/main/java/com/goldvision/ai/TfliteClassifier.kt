package com.goldvision.ai

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * مصنِّف TensorFlow Lite اختياري يعمل على الجهاز لقصاصة كل قطعة متتبَّعة.
 * العقد (يُنشأ بسكربت tools/train_classifier.py):
 *   assets/gold_classifier.tflite : مدخل [1,H,W,3] RGB بقيم 0..255 (float32 أو uint8)، مخرج [1,N] احتمالات
 *   assets/labels.txt            : اسم كل صنف في سطر، ويجب أن يحوي gold_candidate
 * إن لم يوجد الملف يعود load() بـ null ولا يُستخدم أي نموذج (لا نتائج مُحاكاة).
 */
class TfliteClassifier private constructor(
    private val interp: Interpreter,
    private val labels: List<String>,
    private val size: Int,
    private val inFloat: Boolean,
    private val outFloat: Boolean,
    val info: String
) {
    private val goldIdx = labels.indexOf("gold_candidate")
    private val inBuf: ByteBuffer =
        ByteBuffer.allocateDirect(size * size * 3 * (if (inFloat) 4 else 1)).order(ByteOrder.nativeOrder())
    private val pix = IntArray(size * size)

    /** احتمال الصنف gold_candidate كما يخرجه النموذج (ليس إثباتاً ولا نسبة دقة). */
    fun goldProb(crop: Bitmap): Float? {
        if (goldIdx < 0) return null
        return try {
            val bm = Bitmap.createScaledBitmap(crop, size, size, true)
            bm.getPixels(pix, 0, size, 0, 0, size, size)
            inBuf.rewind()
            for (p in pix) {
                val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                if (inFloat) { inBuf.putFloat(r.toFloat()); inBuf.putFloat(g.toFloat()); inBuf.putFloat(b.toFloat()) }
                else { inBuf.put(r.toByte()); inBuf.put(g.toByte()); inBuf.put(b.toByte()) }
            }
            inBuf.rewind()
            if (outFloat) {
                val out = Array(1) { FloatArray(labels.size) }
                interp.run(inBuf, out)
                out[0][goldIdx]
            } else {
                val out = Array(1) { ByteArray(labels.size) }
                interp.run(inBuf, out)
                (out[0][goldIdx].toInt() and 0xFF) / 255f
            }
        } catch (e: Exception) { null }
    }

    fun close() { try { interp.close() } catch (e: Exception) { } }

    companion object {
        fun load(ctx: Context): TfliteClassifier? = try {
            val afd = ctx.assets.openFd("gold_classifier.tflite")
            val buf = afd.createInputStream().channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
            val labels = ctx.assets.open("labels.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() }
            val interp = Interpreter(buf, Interpreter.Options().setNumThreads(2))
            val shape = interp.getInputTensor(0).shape() // [1,h,w,3]
            val inFloat = interp.getInputTensor(0).dataType() == DataType.FLOAT32
            val outFloat = interp.getOutputTensor(0).dataType() == DataType.FLOAT32
            if (!labels.contains("gold_candidate") || shape.size != 4 || shape[3] != 3) { interp.close(); null }
            else TfliteClassifier(interp, labels, shape[1], inFloat, outFloat, "محمّل (${labels.size} أصناف، ${shape[1]}×${shape[2]})")
        } catch (e: Exception) { null }
    }
}
