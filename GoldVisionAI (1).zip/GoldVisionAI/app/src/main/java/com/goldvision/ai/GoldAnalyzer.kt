package com.goldvision.ai

import android.content.Context
import android.graphics.*
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class Level(val ar: String, val color: Int) {
    HIGH("اشتباه بصري مرتفع", 0xFF2E7D32.toInt()),
    MEDIUM("اشتباه بصري متوسط", 0xFFEF6C00.toInt()),
    LOW("اشتباه بصري ضعيف", 0xFF757575.toInt())
}

fun levelOf(score: Int) = if (score >= 70) Level.HIGH else if (score >= 45) Level.MEDIUM else Level.LOW

/** box: إحداثيات مُطبَّعة 0..1 بالنسبة للصورة */
data class Finding(
    val box: RectF,
    val score: Int,
    val stamp: String?,
    val plated: Boolean,
    val reasons: List<String>,
    val hue: Float = 0f,
    val chroma: Float = 0f
) {
    val level get() = levelOf(score)
}

const val DISCLAIMER =
    "هذه النتيجة تقدير بصري فقط وليست إثباتاً لتركيب المعدن. الذهب المطلي والنحاس الأصفر والإكسسوارات " +
        "قد تبدو متشابهة بالكاميرا، والدمغة نفسها قد تكون مقلّدة. للتأكد استخدم حجر المحك/الحمض أو جهاز XRF أو مختبراً معتمداً."

object GoldAnalyzer {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private const val WORK = 480 // أكبر بُعد للتحليل اللوني (السرعة)

    private class Comp(val id: Int, val x0: Int, val y0: Int, val x1: Int, val y1: Int, val cnt: Int)

    // جداول تحويل sRGB -> CIELAB (D65)
    private val lin = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    }
    private val fTab = FloatArray(4097) { i ->
        val t = i / 4096f
        if (t > 0.008856f) Math.cbrt(t.toDouble()).toFloat() else 7.787f * t + 16f / 116f
    }
    private fun fLab(t: Float): Float = fTab[(t * 4096f).toInt().coerceIn(0, 4096)]

    /**
     * المرحلة 1 (سريعة، بدون OCR):
     *  - موازنة بيضاء من المناطق المحايدة (ورقة/خلفية بيضاء) لتقليل أثر لون الإضاءة
     *  - تحويل إلى CIELAB وقياس زاوية اللون hab والتشبّع C* (نفس فضاء ISO 8654 لألوان سبائك الذهب)
     *  - مناطق متصلة -> قياسات لكل قطعة
     * ملاحظة: اللون وحده لا يفرّق الذهب عن النحاس الأصفر المصقول أو الطلاء، لذلك سقف الدرجة بدون دمغة = 69.
     */
    fun detect(src: Bitmap, work: Int = WORK, sens: Sensitivity = Sensitivity.MEDIUM): List<Finding> {
        val sc = work.toFloat() / max(src.width, src.height)
        val w = max(1, (src.width * sc).toInt())
        val h = max(1, (src.height * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        // --- موازنة بيضاء من البكسلات المحايدة فقط ---
        var sr = 0L; var sg = 0L; var sb = 0L; var nn = 0
        for (p in px) {
            val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            if (mx - mn < 30 && mx in 64..240) { sr += r; sg += g; sb += b; nn++ }
        }
        var gr = 1f; var gg = 1f; var gb = 1f
        var wb = false
        if (nn > 0.03f * px.size) {
            val mr = sr.toFloat() / nn; val mg = sg.toFloat() / nn; val mb = sb.toFloat() / nn
            val gray = (mr + mg + mb) / 3f
            gr = (gray / mr).coerceIn(0.8f, 1.25f); gg = (gray / mg).coerceIn(0.8f, 1.25f); gb = (gray / mb).coerceIn(0.8f, 1.25f)
            wb = true
        }

        // --- CIELAB لكل بكسل ---
        val LL = FloatArray(w * h); val HH = FloatArray(w * h); val CC = FloatArray(w * h)
        val mask = BooleanArray(w * h)
        for (i in px.indices) {
            val p = px[i]
            val r = lin[min(255f, Color.red(p) * gr).toInt()]
            val g = lin[min(255f, Color.green(p) * gg).toInt()]
            val b = lin[min(255f, Color.blue(p) * gb).toInt()]
            val x = 0.4124f * r + 0.3576f * g + 0.1805f * b
            val y = 0.2126f * r + 0.7152f * g + 0.0722f * b
            val z = 0.0193f * r + 0.1192f * g + 0.9505f * b
            val fx = fLab(x / 0.95047f); val fy = fLab(y); val fz = fLab(z / 1.08883f)
            val l = 116f * fy - 16f
            val a = 500f * (fx - fy); val bb = 200f * (fy - fz)
            val c = sqrt(a * a + bb * bb)
            var hue = 0f
            if (c >= 8f) {
                hue = Math.toDegrees(Math.atan2(bb.toDouble(), a.toDouble())).toFloat()
                if (hue < 0) hue += 360f
            }
            LL[i] = l; HH[i] = hue; CC[i] = c
            // نطاق واسع للكشف (الجلد والخشب والكرتون hab ≈ 40–65 فتُستبعد)
            mask[i] = hue in 70f..95f && c in sens.minChroma..75f && l in 30f..96f
        }
        val dm = dilate(dilate(mask, w, h), w, h)

        val label = IntArray(w * h)
        val stack = IntArray(w * h)
        val comps = ArrayList<Comp>()
        var next = 0
        for (i in dm.indices) {
            if (!dm[i] || label[i] != 0) continue
            next++
            var sp = 0; stack[sp++] = i; label[i] = next
            var x0 = w; var x1 = 0; var y0 = h; var y1 = 0; var cnt = 0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                cnt++
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                if (x > 0 && dm[p - 1] && label[p - 1] == 0) { label[p - 1] = next; stack[sp++] = p - 1 }
                if (x < w - 1 && dm[p + 1] && label[p + 1] == 0) { label[p + 1] = next; stack[sp++] = p + 1 }
                if (y > 0 && dm[p - w] && label[p - w] == 0) { label[p - w] = next; stack[sp++] = p - w }
                if (y < h - 1 && dm[p + w] && label[p + w] == 0) { label[p + w] = next; stack[sp++] = p + w }
            }
            val bboxArea = (x1 - x0 + 1) * (y1 - y0 + 1)
            if (cnt >= sens.minAreaFrac * w * h && bboxArea <= 0.6f * w * h) comps.add(Comp(next, x0, y0, x1, y1, cnt))
        }

        val out = ArrayList<Finding>()
        for (c in comps.sortedByDescending { it.cnt }.take(12)) {
            val hv = FloatArray(c.cnt); val cv = FloatArray(c.cnt); val lv = FloatArray(c.cnt)
            var n = 0; var tot = 0; var spec = 0
            var sH = 0.0; var sH2 = 0.0; var sL = 0.0; var sL2 = 0.0
            for (y in c.y0..c.y1) for (x in c.x0..c.x1) {
                val p = y * w + x
                if (label[p] != c.id) continue
                tot++
                if (mask[p]) {
                    hv[n] = HH[p]; cv[n] = CC[p]; lv[n] = LL[p]; n++
                    sH += HH[p]; sH2 += HH[p] * HH[p]; sL += LL[p]; sL2 += LL[p] * LL[p]
                } else if (LL[p] > 88f && CC[p] < 14f) spec++
            }
            if (n < 20) continue
            java.util.Arrays.sort(hv, 0, n); java.util.Arrays.sort(cv, 0, n)
            val medH = hv[n / 2]; val medC = cv[n / 2]
            val sdH = sqrt(max(0.0, sH2 / n - (sH / n) * (sH / n)))
            val sdL = sqrt(max(0.0, sL2 / n - (sL / n) * (sL / n)))
            val specRatio = spec.toDouble() / tot

            val reasons = ArrayList<String>()
            reasons += "القياس: زاوية اللون ${medH.toInt()}° ، التشبّع C*=${medC.toInt()}" + if (wb) " (بعد موازنة بيضاء)" else " (بدون مرجع أبيض في الصورة)"
            var score = 0.0

            // زاوية اللون: الذهب الأصفر ≈ 75–88° في CIELAB
            val hScore = max(0.0, 25.0 * (1 - abs(medH - 82f) / 12.0))
            score += hScore
            reasons += when {
                hScore >= 15 -> "زاوية اللون ضمن نطاق الذهب الأصفر"
                medH > 90 -> "اللون يميل إلى الأصفر المخضر (أقرب للنحاس الأصفر أو الأصباغ)"
                medH < 74 -> "اللون يميل إلى المحمر/البرتقالي (نحاس أو ذهب وردي أو جلد/خشب)"
                else -> "اللون ذهبي جزئياً فقط"
            }

            // التشبّع: الذهب الحقيقي ليس شديد التشبّع
            val cScore = when {
                medC in 22f..45f -> 20.0
                medC < 22f -> max(0.0, 20.0 - (22f - medC) * 2)
                else -> max(0.0, 20.0 - (medC - 45f) * 1.5)
            }
            score += cScore
            if (medC > 55f) reasons += "تشبّع عالٍ جداً (يتكرر مع الطلاء الأصفر أو البلاستيك أو الأصباغ)"
            else if (medC < 18f) reasons += "اللون باهت (ذهب أبيض/فضة أو إضاءة ضعيفة)"

            val specScore = when {
                specRatio in 0.015..0.15 -> 20.0
                specRatio < 0.003 -> 0.0
                else -> 8.0
            }
            score += specScore
            reasons += if (specScore >= 20) "توجد لمعات انعكاسية معدنية" else if (specScore == 0.0) "لا لمعات انعكاسية (سطح مطفي/بلاستيك/ضوء ضعيف)" else "لمعان انعكاسي جزئي"

            val tScore = when {
                sdL in 7.0..22.0 -> 15.0
                sdL < 3.5 -> 0.0
                else -> 7.0
            }
            score += tScore
            if (tScore == 0.0) reasons += "السطح متجانس جداً بلا تدرّج ضوئي معدني"

            // التجانس: اختلاف لون القطعة عن نفسها قد يدل على تآكل طلاء أو تلوين غير منتظم
            val uScore = if (sdH < 4) 10.0 else if (sdH < 8) 5.0 else 0.0
            score += uScore
            if (uScore == 0.0) reasons += "اللون غير متجانس داخل القطعة (قد يدل على طلاء متآكل أو أجزاء من معادن مختلفة)"

            // سقف: اللون وحده لا يُثبت الذهب → لا "مرتفع" بدون دمغة مقروءة
            val capped = min(score.toInt(), 69)
            if (score.toInt() > 69) reasons += "تم تحديد الدرجة بسقف 69 لأن اللون وحده لا يفرّق الذهب عن النحاس الأصفر؛ تُرفع فقط بدمغة مقروءة"

            val pad = 0.03f
            val box = RectF(
                max(0f, c.x0.toFloat() / w - pad), max(0f, c.y0.toFloat() / h - pad),
                min(1f, (c.x1 + 1).toFloat() / w + pad), min(1f, (c.y1 + 1).toFloat() / h + pad)
            )
            out += Finding(box, capped, null, false, reasons, medH, medC)
        }
        return out.sortedByDescending { it.score }
    }

    private fun iou(a: RectF, b: RectF): Float {
        val l = max(a.left, b.left); val t = max(a.top, b.top)
        val r = min(a.right, b.right); val bt = min(a.bottom, b.bottom)
        val inter = max(0f, r - l) * max(0f, bt - t)
        val u = a.width() * a.height() + b.width() * b.height() - inter
        return if (u <= 0f) 0f else inter / u
    }

    /** للعرض المباشر: لا يظهر مربع إلا إذا ثبت في عدة إطارات متتالية، والدرجة متوسط الإطارات (يقلل الوميض/العشوائية). */
    fun stabilize(history: List<List<Finding>>, cur: List<Finding>): List<Finding> =
        cur.mapNotNull { f ->
            val matches = history.mapNotNull { frame -> frame.filter { iou(it.box, f.box) > 0.35f }.maxByOrNull { iou(it.box, f.box) } }
            if (matches.size >= 2) f.copy(score = (matches.sumOf { it.score } + f.score) / (matches.size + 1)) else null
        }

    /** المرحلة 2 (أبطأ): التحليل اللوني + قراءة الدمغة من الصورة الأصلية (أعلى 6 قطع). */
    suspend fun analyze(src: Bitmap): List<Finding> = withContext(Dispatchers.Default) {
        detect(src).mapIndexed { i, f -> if (i < 6) applyStamp(f, readText(crop(src, f.box))) else f }
    }

    class StampInfo(val stamp: String?, val plated: Boolean, val silver: Boolean)

    private val platedRx = Regex("GEP|HGE|RGP|PLATED|ELECTROPLATE|K\\s?GP|K\\s?GF|(?<![A-Z])GP(?![A-Z])|(?<![A-Z])GF(?![A-Z])", RegexOption.IGNORE_CASE)
    private val silverRx = Regex("(?<![0-9])925(?![0-9])|STERLING|SILVER", RegexOption.IGNORE_CASE)
    private val karatRx = Regex("(?<![0-9])(9|10|12|14|18|21|22|24)\\s?K(?![A-Z])", RegexOption.IGNORE_CASE)
    private val finenessRx = Regex("(?<![0-9])(375|583|585|750|875|916|917|999|995)(?![0-9])")
    // عيارات القانون المصري 68/1976: 24 و22(916.7) و21(875) و18(750) و14(583.33) و12(500) و9(375)
    private val fineToK = mapOf("375" to "9K", "583" to "14K", "585" to "14K", "750" to "18K", "875" to "21K",
        "916" to "22K", "917" to "22K", "995" to "24K", "999" to "24K")

    private fun norm(t: String): String {
        val sb = StringBuilder()
        for (ch in t) sb.append(
            when (ch) {
                in '٠'..'٩' -> '0' + (ch - '٠')
                in '۰'..'۹' -> '0' + (ch - '۰')
                else -> ch
            }
        )
        return sb.toString()
    }

    private fun parse(raw: String): StampInfo? {
        val t = norm(raw)
        val plated = platedRx.containsMatchIn(t)
        val k = karatRx.find(t)?.groupValues?.get(1)?.let { "${it}K" }
        val f = finenessRx.find(t)?.groupValues?.get(1)?.let { "$it (≈${fineToK[it]})" }
        val stamp = k ?: f
        val silver = stamp == null && silverRx.containsMatchIn(t)
        return if (plated || stamp != null || silver) StampInfo(if (silver) "925 (فضة)" else stamp, plated, silver) else null
    }

    private fun enhance(b: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        val c = 2.0f
        val t = (-0.5f * c + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        Canvas(out).drawBitmap(b, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    private suspend fun readText(b: Bitmap): String {
        val up = if (max(b.width, b.height) < 1200) {
            val s = 1200f / max(b.width, b.height)
            Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
        } else b
        val enh = enhance(up)
        val tries = listOf(up to 0, enh to 0, enh to 90, enh to 270, up to 180)
        val sb = StringBuilder()
        for ((bmp, rot) in tries) {
            sb.append(' ').append(recognizer.process(InputImage.fromBitmap(rotate(bmp, rot), 0)).await().text)
            if (parse(sb.toString()) != null) break
        }
        return sb.toString()
    }

    /** قراءة دمغة من قصاصة (تُستخدم في المسح المباشر بالخلفية). */
    suspend fun readStamp(crop: Bitmap): StampInfo? = parse(readText(crop))

    private fun applyStamp(f: Finding, text: String): Finding {
        val info = parse(text)
        val reasons = f.reasons.toMutableList()
        var score = f.score
        var stamp: String? = null
        var plated = false
        if (info == null) {
            reasons += "لم تُقرأ دمغة (قد تكون صغيرة جداً أو غير واضحة؛ جرّب تقريباً قريباً وإضاءة جانبية). الدرجة تبقى ≤ 69"
        } else {
            stamp = info.stamp; plated = info.plated || info.silver
            if (info.plated) {
                score = min(score, 35)
                reasons += "قُرئ رمز طلاء (GP/GEP/HGE...) ← الأرجح قطعة مطلية"
            } else if (info.silver) {
                score = min(score, 30)
                reasons += "قُرئت دمغة فضة (925) على قطعة ذهبية اللون ← الأرجح فضة مطلية بالذهب"
            } else {
                score = min(100, score + 15)
                reasons += "قُرئت دمغة ${info.stamp}. تنبيه: الدمغة قد تكون مقلّدة (تضبط الجهات الرقابية أدوات تقليد الأختام)، والتحقق الرسمي يكون بدمغة مصلحة الدمغ"
            }
        }
        return f.copy(score = score, stamp = stamp, plated = plated, reasons = reasons)
    }

    private fun dilate(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(m.size)
        for (y in 0 until h) for (x in 0 until w) if (m[y * w + x]) {
            for (dy in -1..1) for (dx in -1..1) {
                val nx = x + dx; val ny = y + dy
                if (nx in 0 until w && ny in 0 until h) o[ny * w + nx] = true
            }
        }
        return o
    }

    fun crop(src: Bitmap, b: RectF): Bitmap {
        val x = (b.left * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (b.top * src.height).toInt().coerceIn(0, src.height - 1)
        val w = ((b.right - b.left) * src.width).toInt().coerceIn(1, src.width - x)
        val h = ((b.bottom - b.top) * src.height).toInt().coerceIn(1, src.height - y)
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    fun annotate(src: Bitmap, fs: List<Finding>): Bitmap {
        val bm = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(bm)
        val unit = max(bm.width, bm.height) / 400f
        val stroke = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * unit; isAntiAlias = true }
        val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
        val txt = Paint().apply { color = Color.WHITE; textSize = 12f * unit; isAntiAlias = true; isFakeBoldText = true }
        fs.forEachIndexed { i, f ->
            stroke.color = f.level.color; fill.color = f.level.color
            val r = RectF(f.box.left * bm.width, f.box.top * bm.height, f.box.right * bm.width, f.box.bottom * bm.height)
            c.drawRoundRect(r, 6 * unit, 6 * unit, stroke)
            val label = "${i + 1}  ${f.score}"
            val tw = txt.measureText(label) + 8 * unit
            c.drawRect(r.left, r.top - 16 * unit, r.left + tw, r.top, fill)
            c.drawText(label, r.left + 4 * unit, r.top - 4 * unit, txt)
        }
        return bm
    }
}

fun rotate(b: Bitmap, deg: Int): Bitmap =
    if (deg % 360 == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

fun limit(b: Bitmap, maxSide: Int): Bitmap {
    val m = max(b.width, b.height)
    if (m <= maxSide) return b
    val s = maxSide.toFloat() / m
    return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
}

fun decodeUri(ctx: Context, uri: Uri): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (max(o.outWidth, o.outHeight) / s > 3000) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
} catch (e: Exception) { null }
