package com.goldvision.ai

import android.content.Context
import android.util.Size

enum class Quality(val ar: String, val analysisSize: Size, val work: Int) {
    LOW("منخفضة", Size(640, 480), 320),
    MEDIUM("متوسطة", Size(960, 720), 480),
    HIGH("عالية", Size(1280, 960), 640)
}

/** حساسية الكشف: أقل تشبّع مقبول، أقل مساحة للقطعة، وحد الدرجة لاعتبارها "مرشحة". */
enum class Sensitivity(val ar: String, val minChroma: Float, val minAreaFrac: Float, val candidateScore: Int) {
    LOW("منخفضة", 20f, 0.004f, 60),
    MEDIUM("متوسطة", 15f, 0.0015f, 52),
    HIGH("عالية", 12f, 0.0008f, 45)
}

data class ScanSettings(
    val fps: Int = 10,
    val quality: Quality = Quality.MEDIUM,
    val sensitivity: Sensitivity = Sensitivity.MEDIUM,
    val liveOcr: Boolean = true
)

object SettingsStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("gv_settings", Context.MODE_PRIVATE)

    fun load(ctx: Context): ScanSettings {
        val p = prefs(ctx)
        return ScanSettings(
            fps = p.getInt("fps", 10).coerceIn(3, 15),
            quality = runCatching { Quality.valueOf(p.getString("quality", "MEDIUM")!!) }.getOrDefault(Quality.MEDIUM),
            sensitivity = runCatching { Sensitivity.valueOf(p.getString("sens", "MEDIUM")!!) }.getOrDefault(Sensitivity.MEDIUM),
            liveOcr = p.getBoolean("ocr", true)
        )
    }

    fun save(ctx: Context, s: ScanSettings) {
        prefs(ctx).edit().putInt("fps", s.fps).putString("quality", s.quality.name)
            .putString("sens", s.sensitivity.name).putBoolean("ocr", s.liveOcr).apply()
    }
}
