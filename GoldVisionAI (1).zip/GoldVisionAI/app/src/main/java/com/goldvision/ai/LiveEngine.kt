package com.goldvision.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class LiveState(val ar: String, val short: String, val color: Int) {
    ANALYZING("جارٍ التحليل", "…", 0xFF9E9E9E.toInt()),
    CANDIDATE("مرشحة للفحص (ذهب محتمل)", "محتمل", 0xFF2E7D32.toInt()),
    UNSURE("نتيجة غير مؤكدة", "غير مؤكد", 0xFFF9A825.toInt()),
    OTHER("نمط أقرب لمعدن آخر", "معدن آخر", 0xFFC62828.toInt())
}

data class TrackView(
    val id: Int, val box: RectF, val state: LiveState, val score: Int, val stability: Int,
    val stamp: String?, val plated: Boolean, val modelP: Float?, val hue: Int, val chroma: Int, val frames: Int
)

data class Snapshot(
    val tracks: List<TrackView>, val fps: Float, val procMs: Int, val thermal: Int, val modelInfo: String, val frames: Long
) {
    companion object { val EMPTY = Snapshot(emptyList(), 0f, 0, 0, "", 0) }
}

fun boxIou(a: RectF, b: RectF): Float {
    val l = max(a.left, b.left); val t = max(a.top, b.top)
    val r = min(a.right, b.right); val bt = min(a.bottom, b.bottom)
    val inter = max(0f, r - l) * max(0f, bt - t)
    val u = a.width() * a.height() + b.width() * b.height() - inter
    return if (u <= 0f) 0f else inter / u
}

/** قطعة متتبَّعة عبر الإطارات: موضع مُنعَّم + سرعة + تاريخ قياسات + حالة بتأخّر زمني (hysteresis). */
class Track(val id: Int, var box: RectF) {
    private var vx = 0f
    private var vy = 0f
    var hits = 0
    var misses = 0
    private val scores = ArrayDeque<Int>()
    private val raws = ArrayDeque<LiveState>()
    private val models = ArrayDeque<Float>()
    var hue = 0f
    var chroma = 0f
    var state = LiveState.ANALYZING
    private var pending = 0
    @Volatile var stamp: String? = null
    @Volatile var plated = false
    @Volatile var validStamp = false
    var ocrTries = 0
    var lastOcrFrame = -100L
    var lastModelFrame = -100L

    fun predicted() = RectF(box.left + vx, box.top + vy, box.right + vx, box.bottom + vy)

    private fun <T> push(q: ArrayDeque<T>, v: T, cap: Int) { q.addLast(v); while (q.size > cap) q.removeFirst() }

    fun meanScore(): Int = if (scores.isEmpty()) 0 else scores.average().toInt()
    fun effScore(): Int = min(100, meanScore() + if (validStamp) 15 else 0)
    fun addModel(p: Float) = push(models, p, 8)
    private fun modelMean(): Float? = if (models.size >= 3) models.takeLast(5).average().toFloat() else null

    private fun rawState(score: Int, sens: Sensitivity): LiveState {
        val eff = min(100, score + if (validStamp) 15 else 0)
        return when {
            plated -> LiveState.OTHER
            hue > 90f || hue < 74f -> LiveState.OTHER
            eff >= sens.candidateScore -> LiveState.CANDIDATE
            eff < 30 -> LiveState.OTHER
            else -> LiveState.UNSURE
        }
    }

    fun measure(det: Finding, sens: Sensitivity) {
        hits++; misses = 0
        push(scores, det.score, 15)
        if (hits == 1) { hue = det.hue; chroma = det.chroma } else { hue = 0.7f * hue + 0.3f * det.hue; chroma = 0.7f * chroma + 0.3f * det.chroma }
        push(raws, rawState(det.score, sens), 15)
        refresh()
    }

    fun update(det: Finding, sens: Sensitivity) {
        val p = predicted()
        val a = 0.6f
        val nb = RectF(
            p.left + (det.box.left - p.left) * a, p.top + (det.box.top - p.top) * a,
            p.right + (det.box.right - p.right) * a, p.bottom + (det.box.bottom - p.bottom) * a
        )
        vx = 0.5f * vx + 0.5f * (nb.centerX() - box.centerX())
        vy = 0.5f * vy + 0.5f * (nb.centerY() - box.centerY())
        box = nb
        measure(det, sens)
    }

    fun coast() { misses++; box = predicted(); vx *= 0.9f; vy *= 0.9f }

    /** التصنيف لا يتغير إلا إذا ثبت التصنيف الجديد في 6 إطارات متتالية (تحليل زمني). */
    private fun refresh() {
        if (hits < 6) { state = LiveState.ANALYZING; return }
        val recent = raws.takeLast(8)
        var cand = recent.groupingBy { it }.eachCount().maxByOrNull { it.value }!!.key
        val mp = modelMean()
        if (mp != null && !plated) {
            cand = when {
                mp >= 0.7f -> if (cand == LiveState.OTHER) LiveState.UNSURE else LiveState.CANDIDATE
                mp <= 0.3f -> LiveState.OTHER
                else -> if (cand == LiveState.CANDIDATE) LiveState.UNSURE else cand
            }
        }
        if (state == LiveState.ANALYZING) { state = cand; pending = 0 }
        else if (cand != state) { pending++; if (pending >= 6) { state = cand; pending = 0 } }
        else pending = 0
    }

    fun applyStamp(info: GoldAnalyzer.StampInfo) {
        if (info.plated || info.silver) { plated = true; validStamp = false; stamp = info.stamp ?: "رمز طلاء" }
        else if (info.stamp != null) { stamp = info.stamp; validStamp = true }
    }

    fun view(): TrackView {
        val stab = if (raws.isEmpty()) 0 else raws.count { it == state } * 100 / raws.size
        return TrackView(id, RectF(box), state, effScore(), stab, stamp, plated, modelMean(), hue.toInt(), chroma.toInt(), hits)
    }
}

class Tracker {
    val tracks = ArrayList<Track>()
    private var nextId = 1

    fun update(dets: List<Finding>, sens: Sensitivity): List<Track> {
        val dUsed = BooleanArray(dets.size)
        val tUsed = BooleanArray(tracks.size)
        val pairs = ArrayList<Triple<Float, Int, Int>>()
        for ((ti, t) in tracks.withIndex()) {
            val p = t.predicted()
            for ((di, d) in dets.withIndex()) {
                val i = boxIou(p, d.box)
                val dx = p.centerX() - d.box.centerX(); val dy = p.centerY() - d.box.centerY()
                val sz = max(max(p.width(), p.height()), max(d.box.width(), d.box.height()))
                val dist = sqrt(dx * dx + dy * dy) / max(sz, 1e-3f)
                if (i > 0.15f || dist < 0.6f) pairs.add(Triple(1f - i + dist, ti, di))
            }
        }
        pairs.sortBy { it.first }
        for ((_, ti, di) in pairs) {
            if (tUsed[ti] || dUsed[di]) continue
            tUsed[ti] = true; dUsed[di] = true
            tracks[ti].update(dets[di], sens)
        }
        for ((ti, t) in tracks.withIndex()) if (!tUsed[ti]) t.coast()
        for ((di, d) in dets.withIndex()) if (!dUsed[di]) {
            val t = Track(nextId++, RectF(d.box)); t.measure(d, sens); tracks.add(t)
        }
        tracks.removeAll { it.misses > 10 || it.box.centerX() !in 0f..1f || it.box.centerY() !in 0f..1f }
        return tracks
    }
}

/** محرك الفحص المباشر: إطار ← كشف/تقطيع ← تتبع ← تحليل زمني ← (اختياري) TFLite و OCR بالخلفية. */
class LiveEngine(ctx: Context) {
    @Volatile var settings = ScanSettings()
    @Volatile var thermal = 0
    @Volatile var paused = false
    @Volatile var errors = 0
    @Volatile var lastFrame: Bitmap? = null
    var onResult: ((Snapshot) -> Unit)? = null

    private val tracker = Tracker()
    private val classifier: TfliteClassifier? = TfliteClassifier.load(ctx)
    val modelInfo: String = classifier?.info ?: "غير موجود (الكشف اللوني الكلاسيكي فقط)"
    private var frameIdx = 0L
    private var lastStart = 0L
    private val stamps = ArrayDeque<Long>()
    private val ocrBusy = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** السرعة الفعلية المستهدفة: تُخفَّض تلقائياً عند ارتفاع حرارة الهاتف. */
    fun targetFps(): Int {
        var f = settings.fps
        if (thermal >= 2) f = min(f, 8)
        if (thermal >= 3) f = min(f, 4)
        return max(1, f)
    }

    fun shouldProcess(now: Long): Boolean {
        if (paused || thermal >= 4) return false
        return now - lastStart >= 1000L / targetFps()
    }

    fun process(frame: Bitmap, now: Long) {
        lastStart = now
        val s = settings
        val dets = GoldAnalyzer.detect(frame, s.quality.work, s.sensitivity)
        val tracks = tracker.update(dets, s.sensitivity)
        frameIdx++

        val clf = classifier
        if (clf != null) {
            var budget = 2
            for (t in tracks.sortedBy { it.lastModelFrame }) {
                if (budget == 0) break
                if (t.hits >= 4 && t.misses == 0) {
                    val p = clf.goldProb(GoldAnalyzer.crop(frame, t.box))
                    if (p != null) t.addModel(p)
                    t.lastModelFrame = frameIdx
                    budget--
                }
            }
        }
        if (s.liveOcr && thermal < 2) maybeOcr(frame, tracks)

        lastFrame = frame
        val end = SystemClock.elapsedRealtime()
        stamps.addLast(end)
        while (stamps.size > 30 || (stamps.isNotEmpty() && end - stamps.first() > 3000)) stamps.removeFirst()
        val fps = if (stamps.size >= 2) (stamps.size - 1) * 1000f / max(1L, stamps.last() - stamps.first()) else 0f
        val views = tracks.filter { it.hits >= 3 && it.misses <= 4 }.map { it.view() }
        onResult?.invoke(Snapshot(views, fps, (end - now).toInt(), thermal, modelInfo, frameIdx))
    }

    /** قراءة الدمغة بالخلفية لأفضل قطعة ثابتة (قراءة واحدة في كل مرة حتى لا تتأخر الكاميرا). */
    private fun maybeOcr(frame: Bitmap, tracks: List<Track>) {
        if (!ocrBusy.compareAndSet(false, true)) return
        val target = tracks.filter {
            it.hits >= 8 && it.misses == 0 && it.stamp == null && !it.plated && it.ocrTries < 4 &&
                frameIdx - it.lastOcrFrame >= 20 && it.box.width() * frame.width >= 60
        }.maxByOrNull { it.meanScore() }
        if (target == null) { ocrBusy.set(false); return }
        target.ocrTries++; target.lastOcrFrame = frameIdx
        val crop = GoldAnalyzer.crop(frame, target.box)
        scope.launch {
            try {
                GoldAnalyzer.readStamp(crop)?.let { target.applyStamp(it) }
            } catch (e: Throwable) { errors++ } finally { ocrBusy.set(false) }
        }
    }

    fun close() { scope.cancel(); classifier?.close() }
}
