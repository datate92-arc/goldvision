package com.goldvision.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF8A6D00))) {
                CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

sealed class Screen {
    object Home : Screen()
    object Live : Screen()
    object Perm : Screen()
    data class Cfg(val backToLive: Boolean) : Screen()
    data class Res(val bmp: Bitmap, val findings: List<Finding>, val saved: Boolean) : Screen()
    object Hist : Screen()
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var busy by remember { mutableStateOf(false) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        screen = if (ok) Screen.Live else Screen.Perm
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val bmp = withContext(Dispatchers.IO) { decodeUri(ctx, uri) }
            if (bmp != null) screen = Screen.Res(bmp, GoldAnalyzer.analyze(bmp), false)
            busy = false
        }
    }
    fun openLive() {
        granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (granted) screen = Screen.Live else permLauncher.launch(Manifest.permission.CAMERA)
    }

    BackHandler(screen !is Screen.Home) {
        val s = screen
        screen = Screen.Home
        if (s is Screen.Cfg && s.backToLive) screen = Screen.Live
    }

    Surface(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            when (val s = screen) {
                Screen.Home -> HomeScreen(
                    onLive = { openLive() }, onGallery = { picker.launch("image/*") },
                    onHistory = { screen = Screen.Hist }, onSettings = { screen = Screen.Cfg(false) }
                )
                Screen.Live -> LiveScreen(onSettings = { screen = Screen.Cfg(true) }, onBack = { screen = Screen.Home })
                Screen.Perm -> PermissionScreen(onRetry = { openLive() }, onBack = { screen = Screen.Home })
                is Screen.Cfg -> SettingsScreen { screen = if (s.backToLive) Screen.Live else Screen.Home }
                is Screen.Res -> ResultScreen(s.bmp, s.findings, s.saved) { screen = Screen.Home }
                Screen.Hist -> HistoryScreen(
                    onOpen = { sc ->
                        val b = HistoryStore.loadBitmap(ctx, sc.id, 2000)
                        if (b != null) screen = Screen.Res(b, sc.findings, true)
                    },
                    onBack = { screen = Screen.Home }
                )
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color(0x99000000)), Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@Composable
fun HomeScreen(onLive: () -> Unit, onGallery: () -> Unit, onHistory: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Gold Vision AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8A6D00))
        Text("ماسح مباشر بالكاميرا: فرز بصري احتمالي للقطع الذهبية", fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Button(onLive, Modifier.fillMaxWidth().height(60.dp)) { Text("فحص مباشر بالكاميرا", fontSize = 18.sp) }
        OutlinedButton(onGallery, Modifier.fillMaxWidth().height(52.dp)) { Text("فحص صورة من المعرض") }
        OutlinedButton(onHistory, Modifier.fillMaxWidth().height(52.dp)) { Text("سجل الفحوصات") }
        OutlinedButton(onSettings, Modifier.fillMaxWidth().height(52.dp)) { Text("إعدادات الفحص") }
        Spacer(Modifier.weight(1f))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) {
            Text(DISCLAIMER, Modifier.padding(14.dp), fontSize = 13.sp)
        }
        Text("نصيحة: ضوء نهار منتشر بدون فلاش، وضع ورقة بيضاء في المشهد (لموازنة اللون)، وقطع غير متراكمة، وقرّب الكاميرا من الدمغات.", fontSize = 12.sp)
    }
}

@Composable
fun PermissionScreen(onRetry: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)) {
        Text("إذن الكاميرا مطلوب", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("الفحص المباشر يحتاج الكاميرا. الصور تُعالَج على الهاتف فقط ولا تُرسل لأي جهة (التطبيق بلا إذن إنترنت).")
        Button(onRetry, Modifier.fillMaxWidth()) { Text("طلب الإذن مرة أخرى") }
        OutlinedButton({
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        }, Modifier.fillMaxWidth()) { Text("فتح إعدادات التطبيق (إن رُفض الإذن نهائياً)") }
        TextButton(onBack) { Text("رجوع") }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(SettingsStore.load(ctx)) }
    fun upd(n: ScanSettings) { s = n; SettingsStore.save(ctx, n) }
    @Composable
    fun <T> Choice(label: String, items: List<T>, sel: T, name: (T) -> String, onPick: (T) -> Unit) {
        Text(label, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach {
                if (it == sel) Button({ onPick(it) }) { Text(name(it)) } else OutlinedButton({ onPick(it) }) { Text(name(it)) }
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("رجوع") }
            Text("إعدادات الفحص", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Choice("سرعة الفحص المستهدفة (إطار/ثانية)", listOf(5, 10, 15), s.fps, { "$it" }) { upd(s.copy(fps = it)) }
        Text("السرعة الفعلية تعتمد على الهاتف وتُخفَّض تلقائياً عند ارتفاع حرارته.", fontSize = 12.sp)
        Choice("جودة المعالجة", Quality.values().toList(), s.quality, { it.ar }) { upd(s.copy(quality = it)) }
        Text("الجودة الأعلى تُظهر تفاصيل أدق لكنها أبطأ وأسخن.", fontSize = 12.sp)
        Choice("حساسية الكشف", Sensitivity.values().toList(), s.sensitivity, { it.ar }) { upd(s.copy(sensitivity = it)) }
        Text("الحساسية العالية تلتقط قطعاً أصغر وأقل لمعاناً لكنها تزيد الإنذارات الخاطئة.", fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(s.liveOcr, { upd(s.copy(liveOcr = it)) })
            Spacer(Modifier.width(10.dp))
            Text("قراءة الدمغات أثناء البث (OCR بالخلفية)")
        }
    }
}

private val StateColors = mapOf(
    LiveState.CANDIDATE to Color(0xFF2E7D32), LiveState.UNSURE to Color(0xFFF9A825),
    LiveState.OTHER to Color(0xFFC62828), LiveState.ANALYZING to Color(0xFF9E9E9E)
)

@RequiresApi(Build.VERSION_CODES.Q)
private fun registerThermal(ctx: Context, onChange: (Int) -> Unit): () -> Unit {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val l = PowerManager.OnThermalStatusChangedListener { onChange(it) }
    onChange(pm.currentThermalStatus)
    pm.addThermalStatusListener(ContextCompat.getMainExecutor(ctx), l)
    return { pm.removeThermalStatusListener(l) }
}

@Composable
fun LiveScreen(onSettings: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val settings = remember { SettingsStore.load(ctx) }
    val engine = remember { LiveEngine(ctx) }
    engine.settings = settings
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val executor = remember { Executors.newSingleThreadExecutor() }
    var snap by remember { mutableStateOf(Snapshot.EMPTY) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoom by remember { mutableFloatStateOf(0f) }
    var camError by remember { mutableStateOf<String?>(null) }
    var bindKey by remember { mutableIntStateOf(0) }
    var retries by remember { mutableIntStateOf(0) }
    var thermal by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    engine.paused = paused

    DisposableEffect(Unit) {
        engine.onResult = { snap = it }
        val win = (ctx as? Activity)?.window
        win?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val unregister = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) registerThermal(ctx) { thermal = it; engine.thermal = it } else null
        onDispose {
            engine.onResult = null
            win?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            unregister?.invoke()
            engine.close()
            executor.shutdown()
        }
    }

    // ربط الكاميرا: يُعاد عند تغيّر الجودة أو بعد انقطاع الكاميرا
    DisposableEffect(settings.quality, bindKey) {
        val selector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy(settings.quality.analysisSize, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
            .build()
        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(selector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        analysis.setAnalyzer(executor) { proxy ->
            try {
                val now = SystemClock.elapsedRealtime()
                if (engine.shouldProcess(now)) {
                    val bmp = rotate(proxy.toBitmap(), proxy.imageInfo.rotationDegrees)
                    engine.process(bmp, now)
                }
            } catch (e: Throwable) {
                engine.errors++
            } finally {
                proxy.close()
            }
        }
        val future = ProcessCameraProvider.getInstance(ctx)
        var observer: Observer<CameraState>? = null
        var cam: Camera? = null
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                val c = provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                cam = c
                camera = c
                val obs = Observer<CameraState> { st ->
                    if (st.error != null) camError = "انقطعت الكاميرا أو تعذّر تشغيلها (رمز ${st.error?.code})"
                    else if (st.type == CameraState.Type.OPEN) { camError = null; retries = 0 }
                }
                observer = obs
                c.cameraInfo.cameraState.observe(owner, obs)
            } catch (e: Exception) {
                camError = "تعذّر تشغيل الكاميرا: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            analysis.clearAnalyzer()
            observer?.let { o -> cam?.cameraInfo?.cameraState?.removeObserver(o) }
            try { future.get().unbindAll() } catch (e: Exception) { }
        }
    }
    // إعادة محاولة تلقائية (3 مرات) عند الانقطاع
    LaunchedEffect(camError) {
        if (camError != null && retries < 3) { delay(2500); retries++; bindKey++ }
    }

    val tracks = snap.tracks
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("رجوع", color = Color.White) }
            TextButton(onSettings) { Text("إعدادات", color = Color.White) }
            TextButton({ paused = !paused }) { Text(if (paused) "استئناف" else "إيقاف مؤقت", color = Color.White) }
            TextButton({
                val f = engine.lastFrame
                if (f != null && tracks.isNotEmpty()) {
                    val list = tracks.map {
                        Finding(it.box, it.score, it.stamp, it.plated,
                            listOf("${it.state.ar} (ثبات ${it.stability}%)، زاوية اللون ${it.hue}° ، التشبّع ${it.chroma}", "لقطة من الفحص المباشر؛ تقدير بصري احتمالي وليس إثباتاً"))
                    }
                    scope.launch(Dispatchers.IO) { HistoryStore.save(ctx, f, list); msg = "تم حفظ لقطة في السجل" }
                } else msg = "لا توجد قطع متتبَّعة لحفظها"
            }) { Text("حفظ لقطة", color = Color.White) }
        }
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())
            Canvas(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTapGestures { o ->
                        camera?.let { c ->
                            val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                            c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                        }
                    }
                }
            ) {
                val bg = android.graphics.Paint().apply { style = android.graphics.Paint.Style.FILL }
                val tp = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 30f; isFakeBoldText = true; isAntiAlias = true }
                tracks.forEach { t ->
                    val tl = Offset(t.box.left * size.width, t.box.top * size.height)
                    val sz = Size(t.box.width() * size.width, t.box.height() * size.height)
                    drawRect(Color(t.state.color), tl, sz, style = Stroke(if (t.state == LiveState.ANALYZING) 3f else 6f))
                    val label = "#${t.id} ${t.state.short} ${t.score}"
                    bg.color = t.state.color
                    val w = tp.measureText(label) + 14f
                    drawContext.canvas.nativeCanvas.drawRect(tl.x, maxOf(0f, tl.y - 38f), tl.x + w, maxOf(0f, tl.y - 38f) + 38f, bg)
                    drawContext.canvas.nativeCanvas.drawText(label, tl.x + 7f, maxOf(0f, tl.y - 38f) + 28f, tp)
                }
            }
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth()) {
                camError?.let {
                    Text(it + if (retries < 3) " — إعادة المحاولة..." else "", color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.fillMaxWidth().background(Color(0xCCC62828)).padding(8.dp))
                    if (retries >= 3) Button({ retries = 0; bindKey++ }, Modifier.padding(8.dp)) { Text("إعادة تشغيل الكاميرا") }
                }
                if (thermal >= 4) Text("الهاتف ساخن جداً: أُوقف التحليل مؤقتاً حتى يبرد", color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0xCCC62828)).padding(8.dp))
                else if (thermal >= 2) Text("الهاتف ساخن: خُفّضت سرعة الفحص تلقائياً", color = Color.Black, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0xCCF9A825)).padding(8.dp))
                if (paused) Text("متوقف مؤقتاً", color = Color.White, modifier = Modifier.fillMaxWidth().background(Color(0xCC424242)).padding(8.dp))
                msg?.let { Text(it, color = Color.White, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().background(Color(0xCC2E7D32)).padding(6.dp)) }
            }
            Slider(zoom, { zoom = it; camera?.cameraControl?.setLinearZoom(it) },
                Modifier.align(Alignment.BottomCenter).padding(horizontal = 24.dp))
        }
        LaunchedEffect(msg) { if (msg != null) { delay(2000); msg = null } }
        Column(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text(
                "القطع المكتشفة: ${tracks.size}   🟢 ${tracks.count { it.state == LiveState.CANDIDATE }}   🟡 ${tracks.count { it.state == LiveState.UNSURE || it.state == LiveState.ANALYZING }}   🔴 ${tracks.count { it.state == LiveState.OTHER }}",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Text(
                "السرعة ${"%.1f".format(Locale.US, snap.fps)} إطار/ث (الهدف ${engine.targetFps()}) · المعالجة ${snap.procMs}ms · نموذج TFLite: ${engine.modelInfo}",
                color = Color(0xFFBDBDBD), fontSize = 11.sp
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(tracks, key = { it.id }) { t ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.size(14.dp).clip(CircleShape).background(StateColors[t.state] ?: Color.Gray))
                        Column {
                            Text("قطعة #${t.id}: ${t.state.ar}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "درجة الاشتباه ${t.score}/100 · ثبات الحكم ${t.stability}% · اللون ${t.hue}°/${t.chroma}" +
                                    (t.stamp?.let { " · دمغة $it" } ?: "") + (t.modelP?.let { " · مخرج النموذج ${(it * 100).toInt()}%" } ?: ""),
                                color = Color(0xFFBDBDBD), fontSize = 11.sp
                            )
                        }
                    }
                }
            }
            Text("فرز بصري احتمالي فقط: الكاميرا لا تثبت أن المعدن ذهب حقيقي ولا تركيبه الكيميائي. الدرجة ليست نسبة دقة.",
                color = Color(0xFFFFE082), fontSize = 11.sp)
        }
    }
}

@Composable
fun ResultScreen(bmp: Bitmap, findings: List<Finding>, saved: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val annotated = remember(bmp, findings) { GoldAnalyzer.annotate(bmp, findings) }
    LaunchedEffect(Unit) { if (!saved) withContext(Dispatchers.IO) { HistoryStore.save(ctx, bmp, findings) } }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onBack) { Text("الرئيسية") }
                Text("نتائج الفحص (${findings.size} قطعة)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
        item { Image(annotated.asImageBitmap(), null, Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) { Text(DISCLAIMER, Modifier.padding(12.dp), fontSize = 12.sp) } }
        if (findings.isEmpty()) item { Text("لم يتم العثور على قطع بلون الذهب. جرّب إضاءة أفضل أو تقريباً أكبر.") }
        items(findings.size) { i ->
            val f = findings[i]
            val thumb = remember(bmp, f) { GoldAnalyzer.crop(bmp, f.box) }
            Card {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Image(thumb.asImageBitmap(), null, Modifier.size(96.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("قطعة ${i + 1}: ${f.level.ar}", fontWeight = FontWeight.Bold, color = Color(f.level.color))
                        Text("درجة الاشتباه البصري: ${f.score} / 100 (مؤشر داخلي غير معايَر، وليس نسبة دقة)", fontSize = 12.sp)
                        Text("الدمغة: " + (f.stamp ?: if (f.plated) "رمز طلاء" else "لم تُقرأ"), fontSize = 13.sp)
                        f.reasons.forEach { Text("• $it", fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(onOpen: (Scan) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var scans by remember { mutableStateOf(HistoryStore.list(ctx)) }
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("الرئيسية") }
            Text("سجل الفحوصات", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        if (scans.isEmpty()) Text("لا توجد فحوصات محفوظة بعد.", Modifier.padding(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(scans, key = { it.id }) { sc ->
                val thumb = remember(sc.id) { HistoryStore.loadBitmap(ctx, sc.id, 300) }
                Card(Modifier.fillMaxWidth().clickable { onOpen(sc) }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        thumb?.let { Image(it.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop) }
                        Column(Modifier.weight(1f)) {
                            Text(fmt.format(Date(sc.time)))
                            Text("${sc.findings.size} قطعة، أعلى درجة: ${sc.findings.maxOfOrNull { it.score } ?: 0}", fontSize = 12.sp)
                        }
                        TextButton({ HistoryStore.delete(ctx, sc.id); scans = HistoryStore.list(ctx) }) { Text("حذف", color = Color.Red) }
                    }
                }
            }
        }
    }
}
